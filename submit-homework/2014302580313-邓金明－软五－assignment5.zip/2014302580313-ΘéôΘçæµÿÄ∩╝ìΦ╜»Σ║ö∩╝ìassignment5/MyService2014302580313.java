package iss.java.mail;

import java.io.IOException;
import java.util.Properties;

import javax.mail.Flags.Flag;
import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import com.sun.mail.imap.IMAPFolder;
import com.sun.mail.imap.IMAPStore;

public class MyService2014302580313 implements IMailService {
    
    private Properties props;
    private Session session;
    private Transport transport;
    private IMAPFolder folder;
    private IMAPStore store;
    
    private String userName = "djming96@sina.com";
    private String password = "＊＊＊＊＊＊";
    
    @Override
    public void connect() throws MessagingException {
        props = new Properties();
        props.put("mail.smtp.host", "smtp.sina.com");
        props.put("mail.smtp.timeout", 5000);
        props.put("mail.imap.timeout", 5000);
        props.put("mail.smtp.auth", "true");
        
        session = Session.getDefaultInstance(props);
    }
    
    @Override
    public void send(String recipient, String subject, Object content) throws MessagingException {
        
        
        MimeMessage msg = new MimeMessage(session);
        msg.setFrom(new InternetAddress(userName));
        msg.setRecipient(Message.RecipientType.TO, new InternetAddress(recipient));
        msg.setSubject(subject);
        msg.setText(content.toString());
        msg.saveChanges();
        
        transport = session.getTransport("smtp");
        transport.connect(userName, password);
        transport.sendMessage(msg, msg.getAllRecipients());
        transport.close();
    }
    
    @Override
    public boolean listen() throws MessagingException {
        boolean hasNewMsg = false;
        
        store = (IMAPStore) session.getStore("imap");
        store.connect("imap.sina.com", userName, password);
        folder = (IMAPFolder) store.getFolder("INBOX");
        folder.open(Folder.READ_ONLY);
        
        hasNewMsg = folder.hasNewMessages();
        
        folder.close(false);
        store.close();
        
        return hasNewMsg;
    }
    
    @Override
    public String getReplyMessageContent(String sender, String subject) throws MessagingException, IOException {
        
        store = (IMAPStore) session.getStore("imaps");
        store.connect("imap.sina.com", userName, password);
        folder = (IMAPFolder) store.getFolder("INBOX");
        folder.open(Folder.READ_WRITE);
        
        Message msg = folder.getMessage(folder.getMessageCount() - 1);
        
        msg.setFlag(Flag.SEEN, true);
        String content = msg.getContent().toString();
        
        folder.close(false);
        store.close();
        return content;
        
    }
    
}

